//
//  BusinessVO.h
//  Chatapp
//
//  Created by mansoor shaikh on 31/07/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BusinessVO : NSObject
@property(nonatomic,retain) NSString *user_id,*username,*fname,*lname,*agentcode;
@end
