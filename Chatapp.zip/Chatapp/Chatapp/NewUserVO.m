//
//  NewUserVO.m
//  Chatapp
//
//  Created by arvind on 8/22/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "NewUserVO.h"

@implementation NewUserVO

@end
