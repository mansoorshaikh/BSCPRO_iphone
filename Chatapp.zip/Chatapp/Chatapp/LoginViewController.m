
//
//  LoginViewController.m
//  Chatapp
//
//  Created by mansoor shaikh on 13/02/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "LoginViewController.h"
#import "UserListViewController.h"
#import "LoginVO.h"
#import "RegisterViewController.h"
#import "MainViewController.h"
#import "Reachability.h"
#import "BusinessVO.h"
@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize clicktologin,userNameText,userPasswordText,profileImage,loginDetailsArray,appDelegate,Logoimg,createAccount,activityIndicator;
- (void)viewDidLoad {
    [super viewDidLoad];
    [activityIndicator stopAnimating];

    self.navigationItem.title=@"";
    self.navigationController.navigationBarHidden=YES;
    appDelegate=[[UIApplication sharedApplication] delegate];
    activityIndicator.hidesWhenStopped=true;
    appDelegate.dataArrayAgent=[[NSMutableArray alloc]init];
    appDelegate.traineeListArray=[[NSMutableArray alloc]init];

    profileImage=[[NSString alloc]init];
    appDelegate=[[UIApplication sharedApplication] delegate];

    //CGFloat width = [UIScreen mainScreen].bounds.size.width;
    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    if(height>=480 && height<568){
        //iphone 4
        Logoimg.layer.frame=CGRectMake(30,50,260,100);
        [Logoimg.layer setCornerRadius:5.0];
        [Logoimg removeFromSuperview];
        [self.view addSubview:Logoimg];

        
        userNameText.layer.frame=CGRectMake(30,170,260,40);
         [userNameText removeFromSuperview];
         [self.view addSubview:userNameText];
         
         userPasswordText.layer.frame=CGRectMake(30,240,260,40);
         [userPasswordText removeFromSuperview];
         [self.view addSubview:userPasswordText];
         
         clicktologin.layer.frame=CGRectMake(90,320,150,40);
        [clicktologin.layer setCornerRadius:5.0];
         [clicktologin removeFromSuperview];
         [self.view addSubview:clicktologin];
        
        createAccount.layer.frame=CGRectMake(90,380,150,40);
        [createAccount.layer setCornerRadius:5.0];
        [createAccount removeFromSuperview];
        [self.view addSubview:createAccount];
        
    }else if(height>=568 && height<600){
        //iphone 5
        
        Logoimg.layer.frame=CGRectMake(30,50,260,100);
        [Logoimg.layer setCornerRadius:5.0];
        [Logoimg removeFromSuperview];
        [self.view addSubview:Logoimg];

        userNameText.layer.frame=CGRectMake(30,170,260,40);
        [userNameText removeFromSuperview];
        [self.view addSubview:userNameText];
        
        userPasswordText.layer.frame=CGRectMake(30,240,260,40);
        [userPasswordText removeFromSuperview];
        [self.view addSubview:userPasswordText];
        
        
        clicktologin.layer.frame=CGRectMake(30,320,130,40);
        [clicktologin.layer setCornerRadius:5.0];
        [clicktologin removeFromSuperview];
        [self.view addSubview:clicktologin];

        createAccount.layer.frame=CGRectMake(90,380,150,40);
        [createAccount.layer setCornerRadius:5.0];
        [createAccount removeFromSuperview];
        [self.view addSubview:createAccount];
        
    }
    
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    if([prefs stringForKey:@"loggedin"]!=nil){
        Reachability *myNetwork = [Reachability reachabilityWithHostname:@"google.com"];
        NetworkStatus myStatus = [myNetwork currentReachabilityStatus];
        if(myStatus == NotReachable)
        {
            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"No internet connection available!!!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
            [alert show];
            
        }else{
        [appDelegate getCountryData];
        [appDelegate getDataSMD];
        [appDelegate getDataCED];
        [appDelegate getDataATASMMD];
        }
        MainViewController *mainvc=[[MainViewController alloc] initWithNibName:@"MainViewController" bundle:nil];
        appDelegate.index=0;
        
        [self.navigationController pushViewController:mainvc animated:YES];
    }
   
}
- (void) threadStartAnimating:(id)data {
    [activityIndicator startAnimating];
    activityIndicator.center = CGPointMake(self.view.frame.size.width / 2.0, self.view.frame.size.height / 2.0);
    [self.view addSubview: activityIndicator];
}
-(IBAction)loginAction{
    Reachability *myNetwork = [Reachability reachabilityWithHostname:@"google.com"];
    NetworkStatus myStatus = [myNetwork currentReachabilityStatus];
    if(myStatus == NotReachable)
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"No internet connection available!!!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        
    }else{
    loginDetailsArray=[[NSMutableArray alloc]init];
    if ([userNameText.text isEqualToString:@""] || [userPasswordText.text isEqualToString:@""]){
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"BSCPRO"
                                                        message:@"Please fill in username and password."
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }else{
        [NSThread detachNewThreadSelector:@selector(threadStartAnimating:) toTarget:self withObject:nil];

        NSString* string2 = [appDelegate.deviceToken stringByReplacingOccurrencesOfString:@" " withString:@""];
        NSURL *url;
        NSMutableString *httpBodyString;
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        httpBodyString=[[NSMutableString alloc] initWithString:[NSString stringWithFormat:@"username=%@&password=%@&device_id=%@&device_type=iPhone",userNameText.text,userPasswordText.text,string2]];
        
        NSString *urlString = [[NSString alloc]initWithFormat:@"https://bscpro.com/auth_api/login"];
        url=[[NSURL alloc] initWithString:urlString];
        NSMutableURLRequest *urlRequest=[NSMutableURLRequest requestWithURL:url];
        
        [urlRequest setHTTPMethod:@"POST"];
        [urlRequest setHTTPBody:[httpBodyString dataUsingEncoding:NSISOLatin1StringEncoding]];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
            // your data or an error will be ready here
            if (error)
            {
                [activityIndicator stopAnimating];
                NSLog(@"Failed to submit request");
            }
            else
            {
                [activityIndicator stopAnimating];
                NSString *content = [[NSString alloc]  initWithBytes:[data bytes]
                                                              length:[data length] encoding: NSUTF8StringEncoding];
                
                NSError *error;
                if ([NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error] == nil) {
                    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"Oops, we encountered an error or the site may be down for maintenance.  Please try again in a few minutes." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                    
                    [alert show];
                    
                }else{
                NSDictionary *userDict=[NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
                    NSString *messages = [[NSString alloc]init];
                    messages = [userDict objectForKey:@"message"];
                    NSString *status = [[NSString alloc]init];
                    status = [userDict objectForKey:@"status"];
                    if([status isEqualToString:@"fail"])
                    {
                        
                        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:messages delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                        [alert show];
                    }else {
                    NSError *error;
            NSDictionary *userDict=[NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
            NSDictionary *userArray = [userDict objectForKey:@"user_profile"];
            LoginVO *lvo=[[LoginVO alloc]init];
                    appDelegate.loginDetails=[[LoginVO alloc] init];
                    appDelegate.loginDetails.userid=[[NSString alloc] init];
                    appDelegate.loginDetails.username=[[NSString alloc] init];
                    appDelegate.loginDetails.firstname=[[NSString alloc] init];
                    appDelegate.loginDetails.lastname=[[NSString alloc] init];
                    appDelegate.loginDetails.timezone=[[NSString alloc] init];
                    appDelegate.loginDetails.profileImage=[[NSString alloc] init];

                    if ([userArray objectForKey:@"username"] != [NSNull null])
                        lvo.userid=[userArray objectForKey:@"userid"];
                    appDelegate.loginDetails.username=[userArray objectForKey:@"username"];
                    appDelegate.loginDetails.firstname=[userArray objectForKey:@"firstname"];
                    appDelegate.loginDetails.lastname=[userArray objectForKey:@"lastname"];
                    appDelegate.loginDetails.timezone=[userArray objectForKey:@"usertimezone"];
                    appDelegate.loginDetails.profileImage=[userArray objectForKey:@"profileImage"];

            /*NSString *valueToSave = @"yes";
            [[NSUserDefaults standardUserDefaults]
             setObject:valueToSave forKey:@"udid"];*/
            
            NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
            [prefs setObject:lvo.userid forKey:@"loggedin"];
            [prefs synchronize];
            
            NSUserDefaults *prefsusername = [NSUserDefaults standardUserDefaults];
            [prefsusername setObject:userNameText.text forKey:@"username"];
            [prefsusername synchronize];
            
            NSUserDefaults *prefspassword = [NSUserDefaults standardUserDefaults];
            [prefspassword setObject:userPasswordText.text forKey:@"password"];
            [prefspassword synchronize];
            
            NSUserDefaults *prefsProfileImg = [NSUserDefaults standardUserDefaults];
            [prefsProfileImg setObject:appDelegate.loginDetails.profileImage forKey:@"profileImage"];
            [prefsProfileImg synchronize];
            
            NSUserDefaults *prefsFIRSTNAME = [NSUserDefaults standardUserDefaults];
            [prefsFIRSTNAME setObject:appDelegate.loginDetails.firstname forKey:@"firstName"];
            [prefsFIRSTNAME synchronize];
            
            NSUserDefaults *prefslastName = [NSUserDefaults standardUserDefaults];
            [prefslastName setObject:appDelegate.loginDetails.lastname forKey:@"lastName"];
            [prefslastName synchronize];
            
            NSUserDefaults *prefstimezone = [NSUserDefaults standardUserDefaults];
            [prefstimezone setObject:appDelegate.loginDetails.timezone forKey:@"timezone"];
            [prefstimezone synchronize];

                        [appDelegate getCountryData];
                        [appDelegate getDataSMD];
                        [appDelegate getDataCED];
                        [appDelegate getDataATASMMD];
                        
                        
                        MainViewController *mainvc=[[MainViewController alloc] initWithNibName:@"MainViewController" bundle:nil];
                        appDelegate.index=0;
                        [self.navigationController pushViewController:mainvc animated:YES];
                            }
                        }
                    }
                }];
            }
        }
}
-(IBAction)registerAction{
    RegisterViewController *rvc=[[RegisterViewController alloc] initWithNibName:@"RegisterViewController" bundle:nil];
    [self.navigationController pushViewController:rvc animated:YES];
    
}
-(void)viewWillAppear:(BOOL)animated{
    if([[NSUserDefaults standardUserDefaults]  objectForKey:@"udid"]== nil){
        }
    self.navigationController.navigationBar.barTintColor = [UIColor clearColor];
    
   
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
