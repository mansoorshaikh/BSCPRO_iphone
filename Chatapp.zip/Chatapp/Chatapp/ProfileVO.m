//
//  ProfileVO.m
//  Chatapp
//
//  Created by arvind on 7/15/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "ProfileVO.h"

@implementation ProfileVO

@end
