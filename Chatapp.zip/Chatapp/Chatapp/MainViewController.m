//
//  MainViewController.m
//  CommunicationApp
//
//  Created by mansoor shaikh on 13/04/14.
//  Copyright (c) 2014 MobiWebCode. All rights reserved.
//

#import "MainViewController.h"
#import "SWRevealViewController.h"
#import "RearViewController.h"
#import "UserListViewController.h"
#import "ProfileViewController.h"
#import "NewRecruitViewController.h"
#import "AddBusinessViewController.h"
#import "NewGuestViewController.h"
#import "MatchUpViewController.h"
#import "OfficeLocatorViewController.h"
#import "LoginViewController.h"
#import "LocationViewController.h"
#import "DashboardViewController.h"
@interface MainViewController ()<SWRevealViewControllerDelegate>

@end

@implementation MainViewController
@synthesize viewController = _viewController;
@synthesize appDelegate,index;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark - SWRevealViewDelegate

#define LogDelegates 0
- (NSString*)stringFromFrontViewPosition:(FrontViewPosition)position
{
    NSString *str = nil;
    if ( position == FrontViewPositionLeftSideMostRemoved ) str = @"FrontViewPositionLeftSideMostRemoved";
    if ( position == FrontViewPositionLeftSideMost) str = @"FrontViewPositionLeftSideMost";
    if ( position == FrontViewPositionLeftSide) str = @"FrontViewPositionLeftSide";
    if ( position == FrontViewPositionLeft ) str = @"FrontViewPositionLeft";
    if ( position == FrontViewPositionRight ) str = @"FrontViewPositionRight";
    if ( position == FrontViewPositionRightMost ) str = @"FrontViewPositionRightMost";
    if ( position == FrontViewPositionRightMostRemoved ) str = @"FrontViewPositionRightMostRemoved";
    return str;
}

- (void)revealController:(SWRevealViewController *)revealController willMoveToPosition:(FrontViewPosition)position
{
    NSLog( @"%@: %@", NSStringFromSelector(_cmd), [self stringFromFrontViewPosition:position]);
}

- (void)revealController:(SWRevealViewController *)revealController didMoveToPosition:(FrontViewPosition)position
{
    NSLog( @"%@: %@", NSStringFromSelector(_cmd), [self stringFromFrontViewPosition:position]);
}

- (void)revealController:(SWRevealViewController *)revealController animateToPosition:(FrontViewPosition)position
{
    NSLog( @"%@: %@", NSStringFromSelector(_cmd), [self stringFromFrontViewPosition:position]);
}

- (void)revealControllerPanGestureBegan:(SWRevealViewController *)revealController;
{
    NSLog( @"%@", NSStringFromSelector(_cmd) );
}

- (void)revealControllerPanGestureEnded:(SWRevealViewController *)revealController;
{
    NSLog( @"%@", NSStringFromSelector(_cmd) );
}

- (void)revealController:(SWRevealViewController *)revealController panGestureBeganFromLocation:(CGFloat)location progress:(CGFloat)progress
{
    NSLog( @"%@: %f, %f", NSStringFromSelector(_cmd), location, progress);
}

- (void)revealController:(SWRevealViewController *)revealController panGestureMovedToLocation:(CGFloat)location progress:(CGFloat)progress
{
    NSLog( @"%@: %f, %f", NSStringFromSelector(_cmd), location, progress);
}

- (void)revealController:(SWRevealViewController *)revealController panGestureEndedToLocation:(CGFloat)location progress:(CGFloat)progress
{
    NSLog( @"%@: %f, %f", NSStringFromSelector(_cmd), location, progress);
}

- (void)revealController:(SWRevealViewController *)revealController willAddViewController:(UIViewController *)viewController forOperation:(SWRevealControllerOperation)operation animated:(BOOL)animated
{
    NSLog( @"%@: %@, %d", NSStringFromSelector(_cmd), viewController, operation);
}

- (void)revealController:(SWRevealViewController *)revealController didAddViewController:(UIViewController *)viewController forOperation:(SWRevealControllerOperation)operation animated:(BOOL)animated
{
    NSLog( @"%@: %@, %d", NSStringFromSelector(_cmd), viewController, operation);
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    appDelegate=[[UIApplication sharedApplication] delegate];
    RearViewController *rearViewController = [[RearViewController alloc] init];
    UINavigationController *frontNavigationController;
    DashboardViewController *dashboard=[[DashboardViewController alloc]initWithNibName:@"DashboardViewController" bundle:nil];
    UserListViewController *userList=[[UserListViewController alloc] initWithNibName:@"UserListViewController" bundle:nil];
    ProfileViewController *pvc=[[ProfileViewController alloc] initWithNibName:@"ProfileViewController" bundle:nil];
    NewRecruitViewController *nrvc=[[NewRecruitViewController alloc] initWithNibName:@"NewRecruitViewController" bundle:nil];
    AddBusinessViewController *addbusinessvc=[[AddBusinessViewController alloc] initWithNibName:@"AddBusinessViewController" bundle:nil];
    NewGuestViewController *newguest=[[NewGuestViewController alloc] initWithNibName:@"NewGuestViewController" bundle:nil];
    MatchUpViewController *matchup=[[MatchUpViewController alloc] initWithNibName:@"MatchUpViewController" bundle:nil];
    OfficeLocatorViewController *officelocator=[[OfficeLocatorViewController alloc] initWithNibName:@"OfficeLocatorViewController" bundle:nil];
    LoginViewController *login=[[LoginViewController alloc] initWithNibName:@"LoginViewController" bundle:nil];
    LocationViewController *location=[[LocationViewController alloc] initWithNibName:@"LocationViewController" bundle:nil];
    if(appDelegate.index==0)
        frontNavigationController = [[UINavigationController alloc] initWithRootViewController:dashboard];
    else if(appDelegate.index==6)
    frontNavigationController = [[UINavigationController alloc] initWithRootViewController:userList];
       else if(appDelegate.index==3)
        frontNavigationController = [[UINavigationController alloc] initWithRootViewController:nrvc];
    else if(appDelegate.index==4)
        frontNavigationController = [[UINavigationController alloc] initWithRootViewController:addbusinessvc];
    else if(appDelegate.index==2)
        frontNavigationController = [[UINavigationController alloc] initWithRootViewController:newguest];
    else if(appDelegate.index==1)
        frontNavigationController = [[UINavigationController alloc] initWithRootViewController:matchup];
        else if(appDelegate.index==5)
        frontNavigationController = [[UINavigationController alloc] initWithRootViewController:location];
    else if(appDelegate.index==7){
        
        frontNavigationController = [[UINavigationController alloc] initWithRootViewController:login];
        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        [prefs removeObjectForKey:@"loggedin"];
        [prefs synchronize];

    }
    UINavigationController *rearNavigationController = [[UINavigationController alloc] initWithRootViewController:rearViewController];
    
    
    SWRevealViewController *revealController = [[SWRevealViewController alloc] initWithRearViewController:rearNavigationController frontViewController:frontNavigationController];
    revealController.delegate = self;

    
    self.viewController = revealController;
	
	 [[[UIApplication sharedApplication] delegate] window].rootViewController = self.viewController;

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
