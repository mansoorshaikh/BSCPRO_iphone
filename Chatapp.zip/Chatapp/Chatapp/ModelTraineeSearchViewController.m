//
//  ModelTraineeSearchViewController.m
//  Chatapp
//
//  Created by arvind on 9/12/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "ModelTraineeSearchViewController.h"
#import "BusinessVO.h"
@interface ModelTraineeSearchViewController ()

@end

@implementation ModelTraineeSearchViewController
@synthesize traineeFieldTableView,userListArray,groupListArray,activityIndicator,appDelegate,searchBar,searchBarController,alert;
- (void)viewDidLoad {
    [super viewDidLoad];
    [activityIndicator stopAnimating];
    appDelegate=[[UIApplication sharedApplication] delegate];
    
    
    // Do any additional setup after loading the view from its nib.
    self.traineeFieldTableView.tableHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.traineeFieldTableView.bounds.size.width, 0.01f)];
    
    UILabel *titleLabel = [[UILabel alloc] init];
    [titleLabel setFrame:CGRectMake(50, 0, 110, 35)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleLabel setText:@"Trainee"];
    titleLabel.textColor=[UIColor blackColor];
    titleLabel.font =[UIFont systemFontOfSize:18];
    self.navigationItem.titleView = titleLabel;
    //self.navigationItem.title=@"Users";
    
    //searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(20, 0,200, 40)];
    searchBar.showsCancelButton = YES;
    [searchBar setDelegate:self];
    //[self.view addSubview:searchBar];
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"navigation.png"]];
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBarHidden=NO;
    filteredContentList=[[NSMutableArray alloc]init];
    filteredContentList=appDelegate.traineeListArray;
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)cancelAction{
    if(self.presentingViewController)
        [self dismissViewControllerAnimated:NO completion:NULL];
    else
        [self.navigationController popViewControllerAnimated:YES];

}- (void)searchTableList {
    NSString *searchString = searchBar.text;
    filteredContentList=[[NSMutableArray alloc]init];
    for (int i=0; i<appDelegate.traineeListArray.count; i++) {
        BusinessVO *bVO=[appDelegate.traineeListArray objectAtIndex:i];
        NSComparisonResult result = [bVO.fname compare:searchString options:(NSCaseInsensitiveSearch|NSDiacriticInsensitiveSearch) range:NSMakeRange(0, [searchString length])];
        if (result == NSOrderedSame)
        {
            [filteredContentList addObject:bVO];
        }
    }
    [traineeFieldTableView reloadData];
}

#pragma mark - Search Implementation

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    isSearching = YES;
}
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if(searchText.length != 0){
        isSearching = YES;
        [self searchTableList];
        
    }else {
        isSearching = NO;
        filteredContentList=[[NSMutableArray alloc]init];
        filteredContentList=appDelegate.traineeListArray;
        // tblContentList.hidden=YES;
    }
    [traineeFieldTableView reloadData];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar {
    [self.searchBar resignFirstResponder];
    NSLog(@"Cancel clicked");
}
- (void)searchBarTextDidEndEditing:(UISearchBar *)aSearchBar {
    [self.searchBar resignFirstResponder];
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)asearchBar {
    NSLog(@"Search Clicked");
    [self.searchBar resignFirstResponder];
    if(searchBar.text  !=nil) {
        isSearching = YES;
        [self searchTableList];
    }else {
        isSearching = NO;
        filteredContentList=[[NSMutableArray alloc]init];
        filteredContentList=appDelegate.traineeListArray;
        // tblContentList.hidden=YES;
    }
    [traineeFieldTableView reloadData];
}
- (void) threadStartAnimating:(id)data {
    [activityIndicator startAnimating];
    activityIndicator.center = CGPointMake(self.view.frame.size.width / 2.0, self.view.frame.size.height / 2.0);
    [self.view addSubview: activityIndicator];
}
-(IBAction)Newmessage{
    
       alert=[[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"Enter trainee name is here..." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    alert.alertViewStyle=UIAlertViewStylePlainTextInput;
    [[alert textFieldAtIndex:0] setPlaceholder:@"Enter trainee name"];
    
    [alert show];
   
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
        appDelegate.traineeId=[[NSString alloc]init];
    appDelegate.tranieeStr=[[NSString alloc]init];

        appDelegate.traineeId=[alert textFieldAtIndex:0].text;
        [alert dismissWithClickedButtonIndex:1 animated:YES];
    if(self.presentingViewController)
        [self dismissViewControllerAnimated:NO completion:NULL];
    else
        [self.navigationController popViewControllerAnimated:YES];
  }

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [filteredContentList count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"MyIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                  reuseIdentifier:MyIdentifier];
    NSString *firstlastname=[[NSString alloc]init];
    if(indexPath.row < [filteredContentList count]){
        BusinessVO *bvo=[filteredContentList objectAtIndex:indexPath.row];
        
        UILabel *userTextView=[[UILabel alloc]initWithFrame:CGRectMake(30,10, 250,30)];
        NSString *str=[[NSString alloc]init];
        NSString *firstString =bvo.fname;
        NSString *secondString = bvo.lname;
        NSString *threestr=bvo.agentcode;
        str = [NSString stringWithFormat:@"%@ %@ %@", firstString, secondString, threestr];
        [userTextView setText:str];
       
        userTextView.font=[UIFont fontWithName:@"Calibri" size:16.0];
        [userTextView setTextColor:[UIColor blackColor]];
        [cell.contentView addSubview:userTextView];
            
        
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 50;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.row < [filteredContentList count]){
        BusinessVO *bvo=[filteredContentList objectAtIndex:indexPath.row];
        appDelegate.tranieeStr=[[NSString alloc]init];
        appDelegate.traineeId=[[NSString alloc]init];
        NSString *str=[[NSString alloc]init];
        NSString *firstString =bvo.fname;
        NSString *secondString = bvo.lname;
        NSString *threestr=bvo.agentcode;
        str = [NSString stringWithFormat:@"%@ %@ %@", firstString, secondString, threestr];
        NSString *userid=[[NSString alloc]init];
        userid=bvo.user_id;
        appDelegate.traineeId=userid;
        appDelegate.tranieeStr=str;
    if(self.presentingViewController)
        [self dismissViewControllerAnimated:NO completion:NULL];
    else
        [self.navigationController popViewControllerAnimated:YES];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
