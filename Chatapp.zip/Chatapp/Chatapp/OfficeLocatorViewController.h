//
//  OfficeLocatorViewController.h
//  Chatapp
//
//  Created by arvind on 7/16/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OfficeLocatorViewController : UIViewController
@property(nonatomic,retain) IBOutlet UILabel *officeLbl,*firstLbl;
@property(nonatomic,retain) IBOutlet UIButton *searchBtn;
@property(nonatomic,retain) IBOutlet UISearchBar *searchBar;
@end
