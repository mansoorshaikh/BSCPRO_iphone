//
//  MessageListViewController.h
//  Chatapp
//
//  Created by arvind on 9/11/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageListViewController : UIViewController
@property(nonatomic,retain) IBOutlet UITableView *messageTableView;
@end
