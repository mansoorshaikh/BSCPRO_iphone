//
//  MsgChatVO.m
//  Chatapp
//
//  Created by arvind on 5/2/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "MsgChatVO.h"

@implementation MsgChatVO

@end
