//
//  LoginVO.m
//  Chatapp
//
//  Created by arvind on 5/4/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "LoginVO.h"

@implementation LoginVO

@end
