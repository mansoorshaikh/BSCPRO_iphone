//
//  GroupChatVO.m
//  Chatapp
//
//  Created by arvind on 5/5/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "GroupChatVO.h"

@implementation GroupChatVO

@end
