//
//  NewGuestViewController.m
//  Chatapp
//
//  Created by arvind on 7/15/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "NewGuestViewController.h"
#import "SWRevealViewController.h"
#import "Reachability.h"
#import "BpmDateViewController.h"
@interface NewGuestViewController ()

@end

@implementation NewGuestViewController
@synthesize questFirstnameTxt,questLastnameTxt,phoneTxt,epmdateTxt,invitedfistnmTxt,invitedLastnmTxt,addLbl,questNameLbl,phoneLbl,epmdateLbl,invitedLbl,saveBtn,datepicker,starttime,theDate,timeDuration,bgimage,viewUp,dateToobar,activityIndicator,userlistTableView,lblarray,dateString,scrollView,bpmSelectTxt,bpmVo,bpmDateArray,appDelegate;
- (void)viewDidLoad {
    [super viewDidLoad];
    [activityIndicator stopAnimating];
    appDelegate=[[UIApplication sharedApplication] delegate];
    appDelegate.bpmuseridStr=[[NSString alloc]init];
    appDelegate.bpmLocationStr=[[NSString alloc]init];
    lblarray=[[NSMutableArray alloc]initWithObjects:@"GUEST NAME",@"",@"PHONE",@"BPM DATE",@"",@"INVITED BY",@"",@"",@"",nil];
    [questFirstnameTxt setDelegate:self];
    [questLastnameTxt setDelegate:self];
    [phoneTxt setDelegate:self];
    [epmdateTxt setDelegate:self];
    [invitedfistnmTxt setDelegate:self];
    [invitedLastnmTxt setDelegate:self];
    [bpmSelectTxt setDelegate:self];
    
    appDelegate.bpmDateArray=[[NSMutableArray alloc]init];
    self.navigationItem.hidesBackButton=YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.translucent = NO;
    
    UILabel *titleLabel = [[UILabel alloc] init];
    [titleLabel setFrame:CGRectMake(50, 0, 110, 35)];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [titleLabel setText:@"ADD NEW GUEST"];
    titleLabel.textColor=[UIColor blackColor];
    titleLabel.font =[UIFont systemFontOfSize:18];
    self.navigationItem.titleView = titleLabel;

    
    SWRevealViewController *revealController = [self revealViewController];
    [revealController panGestureRecognizer];
    [revealController tapGestureRecognizer];
    
    UIBarButtonItem *revealButtonItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"reveal-icon.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]
                                                                         style:UIBarButtonItemStylePlain target:revealController action:@selector(revealToggle:)];
    
    self.navigationItem.leftBarButtonItem = revealButtonItem;
    
    NSUserDefaults *prefstimezone = [NSUserDefaults standardUserDefaults];
    NSString *formDate=[[NSString alloc]init];
    formDate=[prefstimezone objectForKey:@"timezone"];
    NSDate *now = [[NSDate alloc] init];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:formDate];
    [dateFormat setTimeZone:timeZone];
    [dateFormat setDateFormat:@"LL/dd/YYYY"];
    theDate = [dateFormat stringFromDate:now];
    
    //datepicker.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]];
    
    CGFloat yheight = [UIScreen mainScreen].bounds.size.height;
    if(yheight>=568){
        //self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]];
        bgimage.image=[UIImage imageNamed:@"background.png"];
        datepicker.frame=CGRectMake(0, 350,self.view.bounds.size.width, 162);
        
    }else{
        bgimage.image=[UIImage imageNamed:@"background.png"];
        datepicker.frame=CGRectMake(0, 350,self.view.bounds.size.width, 162);
    }
    
    
    epmdateTxt.layer.borderColor=[[UIColor blackColor]CGColor];
    dateToobar.hidden=YES;
    
    datepicker.hidden=YES;
    datepicker.backgroundColor = [UIColor whiteColor];
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    CGFloat yzheight = [UIScreen mainScreen].bounds.size.height;
    if(yzheight>=568){
        scrollView.contentSize=CGSizeMake(width, yzheight+500);
    }else{
        scrollView.contentSize=CGSizeMake(width, yzheight+500);
    }
    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    if(height>=480 && height<568){
        datepicker.frame=CGRectMake(0, 350,self.view.bounds.size.width, 162);
        [datepicker removeFromSuperview];
        [self.view addSubview:datepicker];

        userlistTableView.frame=CGRectMake(20,0,self.view.bounds.size.width,self.view.bounds.size.height-150);
        [userlistTableView removeFromSuperview];
        [self.scrollView addSubview:userlistTableView];
    }else if(height>=568 && height<600){
        userlistTableView.frame=CGRectMake(20,0,self.view.bounds.size.width,self.view.bounds.size.height-150);
        [userlistTableView removeFromSuperview];
        [self.scrollView addSubview:userlistTableView];
        
        datepicker.frame=CGRectMake(0, 350,self.view.bounds.size.width, 162);
        [datepicker removeFromSuperview];
        [self.view addSubview:datepicker];
           }
       userlistTableView.delegate = self;
    userlistTableView.dataSource = self;
    userlistTableView.scrollEnabled = NO;
    // Do any additional setup after loading the view from its nib.
}
-(void)viewDidAppear:(BOOL)animated{
    bpmSelectTxt.text=appDelegate.bpmLocationStr;
    if ([appDelegate.bpmDateArray count]==0) {
        [self BpmDatePost];
    }

}
-(void)doneWithNumberPad{
    [phoneTxt resignFirstResponder];
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField==phoneTxt){
        NSString *currentString = [textField.text stringByReplacingCharactersInRange:range withString:string];
        int length = [currentString length];
        if (length > 12) {
            return NO;
        }
    }
    int length = [self getLength:phoneTxt.text];
    if(length == 12) {
        if(range.length == 0)
            return NO;
    }
    if(length == 3){
        NSString *num = [self formatNumber:phoneTxt.text];
        phoneTxt.text = [NSString stringWithFormat:@"%@-",num];
        if(range.length > 0) {
            phoneTxt.text = [NSString stringWithFormat:@"%@",[num substringToIndex:3]];
        }
    } else if(length == 6) {
        NSString *num = [self formatNumber:phoneTxt.text];
        phoneTxt.text = [NSString stringWithFormat:@"%@-%@-",[num  substringToIndex:3],[num substringFromIndex:3]];
        if(range.length > 0) {
            phoneTxt.text = [NSString stringWithFormat:@"%@-%@",[num substringToIndex:3],[num substringFromIndex:3]];
        }
       }
    return YES;
}
-(NSString*)formatNumber:(NSString*)mobileNumber
{
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    int length = [mobileNumber length];
    if(length > 10)
    {
        mobileNumber = [mobileNumber substringFromIndex: length-10];
    }
    return mobileNumber;
}
-(int)getLength:(NSString*)mobileNumber
{
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"(" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@")" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@" " withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"-" withString:@""];
    mobileNumber = [mobileNumber stringByReplacingOccurrencesOfString:@"+" withString:@""];
    
    int length = [mobileNumber length];
    
    return length;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    
     if(textField==epmdateTxt){
        if(viewUp==YES){
            viewUp=NO;
            //[self animateTextView:NO];
        }
        if(viewUp==NO){
            viewUp=YES;
            //[self animateTextView:YES];
        }
        dateToobar.hidden=YES;
        dateToobar= [[UIToolbar alloc] initWithFrame:CGRectMake(0,307,self.view.bounds.size.width,44)];
        [dateToobar setBarStyle:UIBarStyleBlackOpaque];
        UIBarButtonItem *barButtonDone = [[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                          style:UIBarButtonItemStyleBordered target:self action:@selector(doneBtnPresseds)];
        dateToobar.items = @[barButtonDone];
        barButtonDone.tintColor=[UIColor whiteColor];
        [self.view addSubview:dateToobar];
        
        dateToobar.hidden=NO;
        datepicker.hidden=NO;
        [epmdateTxt resignFirstResponder];
        
        return NO;
    }
     else if (textField==bpmSelectTxt){
         appDelegate=[[UIApplication sharedApplication] delegate];
         if ([appDelegate.bpmDateArray count]==0) {
             [self BpmDatePost];

         }else{
             [bpmSelectTxt resignFirstResponder];
             BpmDateViewController *bpmDateVc=[[BpmDateViewController alloc] initWithNibName:@"BpmDateViewController" bundle:nil];
             [self presentViewController:bpmDateVc animated:YES completion:nil];
         }
     }
    dateToobar.hidden=YES;
       datepicker.hidden=YES;
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}
-(IBAction)doneBtnPresseds{
    
    NSDateFormatter *f2 = [[NSDateFormatter alloc] init];
    [f2 setDateFormat:@"LL/dd/YYYY"];
    NSString *s = [f2 stringFromDate:datepicker.date];
    epmdateTxt.text=[[NSString alloc]initWithFormat:@"%@",s];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [dateFormatter setTimeZone:timeZone];
    [dateFormatter setDateFormat:@"MM/dd/yyyy"];
    dateString = [dateFormatter stringFromDate:datepicker.date];
    dateToobar.hidden=YES;
    datepicker.hidden=YES;
    [self BpmDatePost];
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void) threadStartAnimating:(id)data {
    [activityIndicator startAnimating];
    activityIndicator.center = CGPointMake(self.view.frame.size.width / 2.0, self.view.frame.size.height / 2.0);
    [self.view addSubview: activityIndicator];
}

-(void)BpmDatePost{
    Reachability *myNetwork = [Reachability reachabilityWithHostname:@"google.com"];
    NetworkStatus myStatus = [myNetwork currentReachabilityStatus];
    NSUserDefaults *prefsusername = [NSUserDefaults standardUserDefaults];
    NSUserDefaults *prefspassword = [NSUserDefaults standardUserDefaults];

    if(myStatus == NotReachable)
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"No internet connection available!!!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        
    }else{
        [NSThread detachNewThreadSelector:@selector(threadStartAnimating:) toTarget:self withObject:nil];
        appDelegate.bpmDateArray=[[NSMutableArray alloc]init];

        NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
        
        NSURL *url;
        NSMutableString *httpBodyString;
        httpBodyString=[[NSMutableString alloc] initWithString:[NSString stringWithFormat:@"sec_user=%@&sec_pass=%@&user_id=%@&bpm_date=%@",[prefsusername objectForKey:@"username"],[prefspassword objectForKey:@"password"],[prefs objectForKey:@"loggedin"],epmdateTxt.text]];
        
        NSString *urlString = [[NSString alloc]initWithFormat:@"https://bscpro.com/captains_api/selectbpm"];
        url=[[NSURL alloc] initWithString:urlString];
        NSMutableURLRequest *urlRequest=[NSMutableURLRequest requestWithURL:url];
        
        [urlRequest setHTTPMethod:@"POST"];
        [urlRequest setHTTPBody:[httpBodyString dataUsingEncoding:NSISOLatin1StringEncoding]];
        
        [NSURLConnection sendAsynchronousRequest:urlRequest queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
            // your data or an error will be ready here
            if (error)
            {
                [activityIndicator stopAnimating];
                NSLog(@"Failed to submit request");
                [self BpmDatePost];
            }
            else
            {
                [activityIndicator stopAnimating];
                NSString *content = [[NSString alloc]  initWithBytes:[data bytes]
                                                              length:[data length] encoding: NSUTF8StringEncoding];
                
                NSError *error;
                if ([NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error] == nil) {
                    UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"Oops, we encountered an error or the site may be down for maintenance.  Please try again in a few minutes." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                    
                    [alert show];
                    
                }else{
                    appDelegate.bpmDateArray=[[NSMutableArray alloc]init];
                    NSDictionary *userDict=[NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
                    
                    NSDictionary *userArray = [userDict objectForKey:@"BPMList"];
                    if (userArray == [ NSNull null ] ) {
                        bpmSelectTxt.enabled=false;
                        bpmSelectTxt.text=@"No BPMs On This Day";

                    }else{
                    for (int count=0; count<[userArray allKeys].count; count++) {
                        bpmSelectTxt.enabled=true;
                        bpmSelectTxt.text=@"Please select BPM location";

                        BPMDateVO *bpmvo=[[BPMDateVO alloc] init];

                        bpmvo.bpm_id=[[NSString alloc] init];
                        bpmvo.bpmLocation=[[NSString alloc] init];
                        
                        bpmvo.bpm_id=[userArray allKeys][count];
                        bpmvo.bpmLocation=[userArray objectForKey:[userArray allKeys][count]];
                        
                        [appDelegate.bpmDateArray addObject:bpmvo];

                       
                    }
                    [activityIndicator stopAnimating];
                    
                    }
                }
            }
        }];
    }
    [activityIndicator stopAnimating];
}

-(void)postAllData{
    Reachability *myNetwork = [Reachability reachabilityWithHostname:@"google.com"];
    NetworkStatus myStatus = [myNetwork currentReachabilityStatus];
    if(myStatus == NotReachable)
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"No internet connection available!!!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        
    }else{
        if ([bpmSelectTxt.text isEqual:@"No BPMs On This Day"]) {
            [NSThread detachNewThreadSelector:@selector(threadStartAnimating:) toTarget:self withObject:nil];
            if([questFirstnameTxt.text isEqualToString:@""] || [questLastnameTxt.text isEqualToString:@""] || [phoneTxt.text isEqualToString:@""] ||[invitedfistnmTxt.text isEqualToString:@""] || [invitedLastnmTxt.text isEqualToString:@""]){
                UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"All fields are mandatory.!!!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [alert show];
            }else{
                NSDateFormatter *f2 = [[NSDateFormatter alloc] init];
                [f2 setDateFormat:@"LL/dd/YYYY"];
                NSString *s = [f2 stringFromDate:datepicker.date];
                epmdateTxt.text=[[NSString alloc]initWithFormat:@"%@",s];
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
                [dateFormatter setTimeZone:timeZone];
                [dateFormatter setDateFormat:@"MM/dd/yyyy"];
                dateString = [dateFormatter stringFromDate:datepicker.date];
                
                NSURL *url;
                NSMutableString *httpBodyString;
                NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
                
                NSUserDefaults *prefsusername = [NSUserDefaults standardUserDefaults];
                NSUserDefaults *prefspassword = [NSUserDefaults standardUserDefaults];
                httpBodyString=[[NSMutableString alloc] initWithString:[NSString stringWithFormat:@"user_id=%@&sec_user=%@&sec_pass=%@&guest_fname=%@&guest_lname=%@&phone=%@&bpm_date=%@&inviter_fname=%@&inviter_lname=%@&bpm_id=@""",[prefs objectForKey:@"loggedin"],[prefsusername objectForKey:@"username"],[prefspassword objectForKey:@"password"],questFirstnameTxt.text,questLastnameTxt.text,phoneTxt.text,dateString,invitedfistnmTxt.text,invitedLastnmTxt.text]];
                NSString *urlString = [[NSString alloc]initWithFormat:@"https://bscpro.com/captains_api"];
                url=[[NSURL alloc] initWithString:urlString];
                NSMutableURLRequest *urlRequest=[NSMutableURLRequest requestWithURL:url];
                
                [urlRequest setHTTPMethod:@"POST"];
                [urlRequest setHTTPBody:[httpBodyString dataUsingEncoding:NSISOLatin1StringEncoding]];
                
                [NSURLConnection sendAsynchronousRequest:urlRequest queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
                    // your data or an error will be ready here
                    if (error)
                    {
                        NSLog(@"Failed to submit request");
                        [activityIndicator stopAnimating];
                    }
                    else
                    {
                        NSString *content = [[NSString alloc]  initWithBytes:[data bytes]
                                                                      length:[data length] encoding: NSUTF8StringEncoding];
                        
                        NSError *error;
                        if ([NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error] == nil) {
                            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"Oops, we encountered an error or the site may be down for maintenance.  Please try again in a few minutes." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                            
                            [alert show];
                        }else{
                            
                            NSDictionary *userDict=[NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
                            NSString *messages = [[NSString alloc]init];
                            messages = [userDict objectForKey:@"message"];
                            NSString *status = [[NSString alloc]init];
                            status = [userDict objectForKey:@"status"];
                            if([status isEqualToString:@"fail"])
                            {
                                
                                UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:messages delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                                [alert show];
                            }else if([status isEqualToString:@"ok"]){
                                UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:messages delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                                [alert show];
                                [userlistTableView reloadData];
                            }
                            NSLog(@"contents : %@",content);
                        }
                    }
                    [activityIndicator stopAnimating];
                }];
            }
        }else if ([bpmSelectTxt.text isEqual:@"Please select BPM location"]){
            [NSThread detachNewThreadSelector:@selector(threadStartAnimating:) toTarget:self withObject:nil];
            if([questFirstnameTxt.text isEqualToString:@""] || [questLastnameTxt.text isEqualToString:@""] || [phoneTxt.text isEqualToString:@""] ||[invitedfistnmTxt.text isEqualToString:@""] || [invitedLastnmTxt.text isEqualToString:@""] || [appDelegate.bpmuseridStr isEqualToString:@""]){
                UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"All fields are mandatory.!!!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                [alert show];
            }else{
                NSDateFormatter *f2 = [[NSDateFormatter alloc] init];
                [f2 setDateFormat:@"LL/dd/YYYY"];
                NSString *s = [f2 stringFromDate:datepicker.date];
                epmdateTxt.text=[[NSString alloc]initWithFormat:@"%@",s];
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
                [dateFormatter setTimeZone:timeZone];
                [dateFormatter setDateFormat:@"MM/dd/yyyy"];
                dateString = [dateFormatter stringFromDate:datepicker.date];
                
                NSURL *url;
                NSMutableString *httpBodyString;
                NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
                
                NSUserDefaults *prefsusername = [NSUserDefaults standardUserDefaults];
                NSUserDefaults *prefspassword = [NSUserDefaults standardUserDefaults];
                httpBodyString=[[NSMutableString alloc] initWithString:[NSString stringWithFormat:@"user_id=%@&sec_user=%@&sec_pass=%@&guest_fname=%@&guest_lname=%@&phone=%@&bpm_date=%@&inviter_fname=%@&inviter_lname=%@&bpm_id=%@",[prefs objectForKey:@"loggedin"],[prefsusername objectForKey:@"username"],[prefspassword objectForKey:@"password"],questFirstnameTxt.text,questLastnameTxt.text,phoneTxt.text,dateString,invitedfistnmTxt.text,invitedLastnmTxt.text,appDelegate.bpmuseridStr]];
                NSString *urlString = [[NSString alloc]initWithFormat:@"https://bscpro.com/captains_api"];
                url=[[NSURL alloc] initWithString:urlString];
                NSMutableURLRequest *urlRequest=[NSMutableURLRequest requestWithURL:url];
                
                [urlRequest setHTTPMethod:@"POST"];
                [urlRequest setHTTPBody:[httpBodyString dataUsingEncoding:NSISOLatin1StringEncoding]];
                
                [NSURLConnection sendAsynchronousRequest:urlRequest queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
                    // your data or an error will be ready here
                    if (error)
                    {
                        NSLog(@"Failed to submit request");
                        [activityIndicator stopAnimating];
                    }
                    else
                    {
                        NSString *content = [[NSString alloc]  initWithBytes:[data bytes]
                                                                      length:[data length] encoding: NSUTF8StringEncoding];
                        
                        NSError *error;
                        if ([NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&error] == nil) {
                            UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"Oops, we encountered an error or the site may be down for maintenance.  Please try again in a few minutes." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                            
                            [alert show];
                        }else{
                            
                            NSDictionary *userDict=[NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
                            NSString *messages = [[NSString alloc]init];
                            messages = [userDict objectForKey:@"message"];
                            NSString *status = [[NSString alloc]init];
                            status = [userDict objectForKey:@"status"];
                            if([status isEqualToString:@"fail"])
                            {
                                
                                UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"Error adding new guest, Please try again later" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                                [alert show];
                            }else if([status isEqualToString:@"ok"]){
                                UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"BSCPRO" message:@"New guest added successfully" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                                [alert show];
                                [userlistTableView reloadData];
                            }
                            NSLog(@"contents : %@",content);
                        }
                    }
                    [activityIndicator stopAnimating];
                }];
            }
        }
        
    [activityIndicator stopAnimating];
    }
}
-(void)clearData{
    questFirstnameTxt.text=@"";
    questLastnameTxt.text=@"";
    phoneTxt.text=@"";
    epmdateTxt.text=@"";
    invitedfistnmTxt.text=@"";
    invitedLastnmTxt.text=@"";
   }

-(IBAction)postData{
    [self postAllData];
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [lblarray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    
    // Let's set some custom cell options.
    // Set the cell's background.
    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    if(height>=480 && height<568){
        UILabel *fieldLBls=[[UILabel alloc]initWithFrame:CGRectMake(15,5,130,55)];
        [fieldLBls setText:[lblarray objectAtIndex:[indexPath row]]];
        fieldLBls.textAlignment=NSTextAlignmentLeft;
        fieldLBls.lineBreakMode = NSLineBreakByWordWrapping;
        fieldLBls.numberOfLines = 0;
        [fieldLBls setFont:[UIFont fontWithName:@"Calibri-Bold" size:16.0]];
        [cell.contentView addSubview:fieldLBls];
        if(indexPath.row==0){
            questFirstnameTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            questFirstnameTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            questFirstnameTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:questFirstnameTxt];
            questFirstnameTxt.delegate = self;
            questFirstnameTxt.placeholder=@"First Name";
        }else if(indexPath.row==1){
            questLastnameTxt= [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            questLastnameTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            questLastnameTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:questLastnameTxt];
            questLastnameTxt.delegate = self;
            questLastnameTxt.placeholder=@"Last Name";
        }else if(indexPath.row==2){
            phoneTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            phoneTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            phoneTxt.textAlignment=NSTextAlignmentRight;
            [phoneTxt setKeyboardType:UIKeyboardTypeNumberPad];
            [cell.contentView addSubview:phoneTxt];
            phoneTxt.delegate = self;
            phoneTxt.placeholder=@"888-888-8888";
            UIToolbar* numberToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
            numberToolbar.barStyle = UIBarStyleBlackTranslucent;
            numberToolbar.items = @[[[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelNumberPad)],
                                    [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                                    [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneWithNumberPad)]];
            [numberToolbar sizeToFit];
            phoneTxt.inputAccessoryView = numberToolbar;
        }else if(indexPath.row==3){
            epmdateTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            epmdateTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            epmdateTxt.textAlignment=NSTextAlignmentRight;
             epmdateTxt.text=theDate;
            [cell.contentView addSubview:epmdateTxt];
            epmdateTxt.delegate = self;
            epmdateTxt.placeholder=@"BPM DATE";
            epmdateTxt.text=theDate;

            
        }else if(indexPath.row==4){
            bpmSelectTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            bpmSelectTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            bpmSelectTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:bpmSelectTxt];
            bpmSelectTxt.delegate = self;
            if([appDelegate.bpmDateArray count]==0)
                bpmSelectTxt.text=@"No BPMs On This Day";
            else
                bpmSelectTxt.text=@"Please select one BPM Location";
        }else if(indexPath.row==5){
            invitedfistnmTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            invitedfistnmTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            invitedfistnmTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:invitedfistnmTxt];
            invitedfistnmTxt.delegate = self;
            
            invitedfistnmTxt.placeholder=@"First Name";
            
        }else if(indexPath.row==6){
            invitedLastnmTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            invitedLastnmTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            invitedLastnmTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:invitedLastnmTxt];
            invitedLastnmTxt.delegate = self;
            invitedLastnmTxt.placeholder=@"Last Name";
            
        }else if(indexPath.row==8){
            saveBtn = [[UIButton alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,60)];
            [saveBtn setTitle:@"ADD TO TRACKER" forState:UIControlStateNormal];
            [saveBtn setBackgroundImage:[UIImage imageNamed:@"proBtn.png"] forState:UIControlStateNormal];
            [saveBtn addTarget:self action:@selector(postData) forControlEvents:UIControlEventTouchUpInside];
            [saveBtn removeFromSuperview];
            [cell.contentView addSubview:saveBtn];
        }

    }else if(height>=568 && height<600){
    UILabel *fieldLBls=[[UILabel alloc]initWithFrame:CGRectMake(15,5,130,55)];
    [fieldLBls setText:[lblarray objectAtIndex:[indexPath row]]];
    fieldLBls.textAlignment=NSTextAlignmentLeft;
    fieldLBls.lineBreakMode = NSLineBreakByWordWrapping;
    fieldLBls.numberOfLines = 0;
    [fieldLBls setFont:[UIFont fontWithName:@"Calibri-Bold" size:16.0]];
    [cell.contentView addSubview:fieldLBls];
    if(indexPath.row==0){
        questFirstnameTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
        questFirstnameTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
        questFirstnameTxt.textAlignment=NSTextAlignmentRight;
        [cell.contentView addSubview:questFirstnameTxt];
        questFirstnameTxt.delegate = self;
        questFirstnameTxt.placeholder=@"First Name";
    }else if(indexPath.row==1){
        questLastnameTxt= [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
        questLastnameTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
        questLastnameTxt.textAlignment=NSTextAlignmentRight;
        [cell.contentView addSubview:questLastnameTxt];
        questLastnameTxt.delegate = self;
        questLastnameTxt.placeholder=@"Last Name";
    }else if(indexPath.row==2){
        phoneTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
        phoneTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
        phoneTxt.textAlignment=NSTextAlignmentRight;
        [phoneTxt setKeyboardType:UIKeyboardTypeNumberPad];
        [cell.contentView addSubview:phoneTxt];
        phoneTxt.delegate = self;
        phoneTxt.placeholder=@"888-888-8888";
        UIToolbar* numberToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
        numberToolbar.barStyle = UIBarStyleBlackTranslucent;
        numberToolbar.items = @[[[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelNumberPad)],
                                [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                                [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneWithNumberPad)]];
        [numberToolbar sizeToFit];
        phoneTxt.inputAccessoryView = numberToolbar;
    }else if(indexPath.row==3){
        epmdateTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
        epmdateTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
        epmdateTxt.textAlignment=NSTextAlignmentRight;
         epmdateTxt.text=theDate;
        [cell.contentView addSubview:epmdateTxt];
        epmdateTxt.delegate = self;
        epmdateTxt.placeholder=@"BPM DATE";
        epmdateTxt.text=theDate;

    }else if(indexPath.row==4){
        bpmSelectTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
        bpmSelectTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
        bpmSelectTxt.textAlignment=NSTextAlignmentRight;
        [cell.contentView addSubview:bpmSelectTxt];
        bpmSelectTxt.delegate = self;
        bpmSelectTxt.placeholder=@"No BPMs On This Day";
        
    }else if(indexPath.row==5){
        invitedfistnmTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
        invitedfistnmTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
        invitedfistnmTxt.textAlignment=NSTextAlignmentRight;
        [cell.contentView addSubview:invitedfistnmTxt];
        invitedfistnmTxt.delegate = self;
        invitedfistnmTxt.placeholder=@"First Name";
        
    }else if(indexPath.row==6){
        invitedLastnmTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
        invitedLastnmTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
        invitedLastnmTxt.textAlignment=NSTextAlignmentRight;
        [cell.contentView addSubview:invitedLastnmTxt];
        invitedLastnmTxt.delegate = self;
        invitedLastnmTxt.placeholder=@"Last Name";
        
    }else if(indexPath.row==8){
        saveBtn = [[UIButton alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,60)];
        [saveBtn setTitle:@"ADD TO TRACKER" forState:UIControlStateNormal];
        [saveBtn setBackgroundImage:[UIImage imageNamed:@"proBtn.png"] forState:UIControlStateNormal];
        [saveBtn addTarget:self action:@selector(postData) forControlEvents:UIControlEventTouchUpInside];
        [saveBtn removeFromSuperview];
        [cell.contentView addSubview:saveBtn];
    }
    }else{
        UILabel *fieldLBls=[[UILabel alloc]initWithFrame:CGRectMake(15,5,130,55)];
        [fieldLBls setText:[lblarray objectAtIndex:[indexPath row]]];
        fieldLBls.textAlignment=NSTextAlignmentLeft;
        fieldLBls.lineBreakMode = NSLineBreakByWordWrapping;
        fieldLBls.numberOfLines = 0;
        [fieldLBls setFont:[UIFont fontWithName:@"Calibri-Bold" size:16.0]];
        [cell.contentView addSubview:fieldLBls];
        if(indexPath.row==0){
            questFirstnameTxt = [[UITextField alloc] initWithFrame:CGRectMake(150,5,200,55)];
            questFirstnameTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            questFirstnameTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:questFirstnameTxt];
            questFirstnameTxt.delegate = self;
            questFirstnameTxt.placeholder=@"First Name";
        }else if(indexPath.row==1){
            questLastnameTxt= [[UITextField alloc] initWithFrame:CGRectMake(150,5,200,55)];
            questLastnameTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            questLastnameTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:questLastnameTxt];
            questLastnameTxt.delegate = self;
            questLastnameTxt.placeholder=@"Last Name";
        }else if(indexPath.row==2){
            phoneTxt = [[UITextField alloc] initWithFrame:CGRectMake(150,5,200,55)];
            phoneTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            phoneTxt.textAlignment=NSTextAlignmentRight;
            [phoneTxt setKeyboardType:UIKeyboardTypeNumberPad];
            [cell.contentView addSubview:phoneTxt];
            phoneTxt.delegate = self;
            phoneTxt.placeholder=@"888-888-8888";
            UIToolbar* numberToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
            numberToolbar.barStyle = UIBarStyleBlackTranslucent;
            numberToolbar.items = @[[[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelNumberPad)],
                                    [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                                    [[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(doneWithNumberPad)]];
            [numberToolbar sizeToFit];
            phoneTxt.inputAccessoryView = numberToolbar;
        }else if(indexPath.row==3){
            epmdateTxt = [[UITextField alloc] initWithFrame:CGRectMake(150,5,200,55)];
            epmdateTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            epmdateTxt.textAlignment=NSTextAlignmentRight;
             epmdateTxt.text=theDate;
            [cell.contentView addSubview:epmdateTxt];
            epmdateTxt.delegate = self;
            epmdateTxt.placeholder=@"BPM DATE";
            epmdateTxt.text=theDate;

        }else if(indexPath.row==4){
            bpmSelectTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            bpmSelectTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            bpmSelectTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:bpmSelectTxt];
            bpmSelectTxt.delegate = self;
            bpmSelectTxt.placeholder=@"No BPMs On This Day";
            
        }else if(indexPath.row==5){
            invitedfistnmTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            invitedfistnmTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            invitedfistnmTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:invitedfistnmTxt];
            invitedfistnmTxt.delegate = self;
            invitedfistnmTxt.placeholder=@"First Name";
            
        }else if(indexPath.row==6){
            invitedLastnmTxt = [[UITextField alloc] initWithFrame:CGRectMake(130,5,180,55)];
            invitedLastnmTxt.font=[UIFont fontWithName:@"Calibri" size:16.0];
            invitedLastnmTxt.textAlignment=NSTextAlignmentRight;
            [cell.contentView addSubview:invitedLastnmTxt];
            invitedLastnmTxt.delegate = self;
            invitedLastnmTxt.placeholder=@"Last Name";
            
        }else if(indexPath.row==8){
            saveBtn = [[UIButton alloc] initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,60)];
            [saveBtn setTitle:@"ADD TO TRACKER" forState:UIControlStateNormal];
            [saveBtn setBackgroundImage:[UIImage imageNamed:@"proBtn.png"] forState:UIControlStateNormal];
            [saveBtn addTarget:self action:@selector(postData) forControlEvents:UIControlEventTouchUpInside];
            [saveBtn removeFromSuperview];
            [cell.contentView addSubview:saveBtn];
        }

    }
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 60;
    
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    NSString *sectionName;
    switch (section)
    {
        case 0:
            sectionName = NSLocalizedString(@" ", @" ");
            break;
            
        default:
            sectionName = @"";
            break;
    }
    return sectionName;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
