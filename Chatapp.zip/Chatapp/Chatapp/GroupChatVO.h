//
//  GroupChatVO.h
//  Chatapp
//
//  Created by arvind on 5/5/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GroupChatVO : NSObject
@property(nonatomic,retain) NSString *groupid,*message_id,*user_id,*username,*receiver_id,*receiver,*message_time,*message,*subject,*attach_image,*attach_file,*matchup_id;
@end
