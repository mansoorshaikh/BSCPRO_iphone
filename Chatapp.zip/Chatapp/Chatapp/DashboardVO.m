//
//  DashboardVO.m
//  Chatapp
//
//  Created by arvind on 9/21/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "DashboardVO.h"

@implementation DashboardVO

@end
