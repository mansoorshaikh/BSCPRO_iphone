//
//  GroupVO.h
//  Chatapp
//
//  Created by arvind on 5/4/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GroupVO : NSObject
@property(nonatomic,retain) NSString *groupid,*userid,*username,*profileImage,*groupmemberdetail,*groupName,*groupIcon,*messageid,*message,*attach_image,*attach_file,*msg_time,*firstname,*lastname;
@end
