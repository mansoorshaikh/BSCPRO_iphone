//
//  ProfileVO.h
//  Chatapp
//
//  Created by arvind on 7/15/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProfileVO : NSObject
@property(nonatomic,retain) NSString *firstname,*lastname,*level,*agentid,*licenses,*language,*address,*city,*state,*zipcode,*email,*country,*phone,*timezone,*uplineSA_MD,*ceo_evc,*smd_emd,*username,*profileImg;
@end
