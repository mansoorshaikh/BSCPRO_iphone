//
//  CEOSMDVO.m
//  Chatapp
//
//  Created by arvind on 7/14/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "CEOSMDVO.h"

@implementation CEOSMDVO

@end
