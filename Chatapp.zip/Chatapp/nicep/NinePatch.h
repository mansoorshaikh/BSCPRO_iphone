/*
 *  NinePatch.h
 *  NinePatch
 *
 *  Copyright 2010 Tortuga 22, Inc. All rights reserved.
 *
 */

#import <UIKit/UIKit.h>
#import <CoreGraphics/CoreGraphics.h>

#import "TUNinePatchProtocols.h"
#import "TUNinePatch.h"
#import "TUNinePatchCache.h"
#import "TUDebugLoggingAssistant.h"