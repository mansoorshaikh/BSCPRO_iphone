//
//  BPMDateVO.m
//  Chatapp
//
//  Created by arvind on 9/28/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "BPMDateVO.h"

@implementation BPMDateVO

@end
