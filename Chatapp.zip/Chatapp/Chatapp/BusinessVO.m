//
//  BusinessVO.m
//  Chatapp
//
//  Created by mansoor shaikh on 31/07/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "BusinessVO.h"

@implementation BusinessVO

@end
